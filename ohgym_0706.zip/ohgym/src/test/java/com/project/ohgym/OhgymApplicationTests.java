package com.project.ohgym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OhgymApplicationTests {

    @Test
    void contextLoads() {
    }

}
