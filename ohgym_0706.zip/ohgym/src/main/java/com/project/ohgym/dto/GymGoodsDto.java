package com.project.ohgym.dto;

import lombok.Data;

@Data
public class GymGoodsDto {
    private int ggoodsnum;
    private String ggoodsname;
    private int ggoodsprice;
    private boolean ggoodsaction;
    private String ggoodsadd;
    private String ggoodsperiod;
    private int gymnum;


}
