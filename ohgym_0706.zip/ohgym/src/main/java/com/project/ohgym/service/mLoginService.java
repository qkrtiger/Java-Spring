package com.project.ohgym.service;

import com.project.ohgym.dao.MemberDao;
import com.project.ohgym.dto.MemberDto;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Service
@Slf4j
public class mLoginService {

    @Autowired
    private MemberDao mDao;

    private ModelAndView mv;

    //비밀번호 암호화를 위한 인코더 객체
    private BCryptPasswordEncoder pEncoder =
            new BCryptPasswordEncoder();

    //로그인 처리용 메소드
    public String loginProc(MemberDto member, HttpSession session, RedirectAttributes rttr) {
        String view = null;
        String msg = null;

        //DB에서 회원의 비밀번호 구하기(암호문)
        String encPwd = mDao.selectPass(member.getMid());
        //encPwd에 담겨있을 수 있는 데이터
        // 1) null : 비회원인 경우
        // 2) 암호화된 비밀번호 문자열 : 회원인 경우
        if(encPwd != null){
            //아이디는 맞음.(회원의 아이디)
            if(pEncoder.matches(member.getMpass(), encPwd)){
                //matches 메소드 : Spring Security 에서 제공하는
                //암호문과 평문 비교 메소드.
                //matches(평문, 암호문) 형식으로 작성하면,
                //같은 값일 때 true, 다르면 false를 출력.

                //비밀번호가 맞는 경우
                //세션에 로그인 성공정보(접속자 정보) 저장.
                //  저장할 회원 정보 : id, name, point, g_name
                member = mDao.selectMember(member.getMid());
                //세션에 DTO 저장.
                session.setAttribute("mb", member);

                //로그인 성공 후 페이지 이동처리
                //테스트 페이지로 이동(나중에 변경하기)
                view = "redirect:/";
                msg = "로그인 성공";

        } else {
            //비밀번호가 틀린 경우
            view = "redirect:loginForm";
            msg = "비밀번호 오류";
            }
        } else {
            //아이디 없음(비회원)
            view = "redirect:loginForm";
            msg = "아이디가 존재하지 않습니다.";
        }

        rttr.addFlashAttribute("msg", msg);
        return view;
    }
}
