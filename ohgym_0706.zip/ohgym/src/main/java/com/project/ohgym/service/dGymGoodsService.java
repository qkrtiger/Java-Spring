package com.project.ohgym.service;

import com.project.ohgym.dao.GymGoodsDao;
import com.project.ohgym.dao.MemberDao;
import com.project.ohgym.dto.GymDto;
import com.project.ohgym.dto.GymGoodsDto;
import com.project.ohgym.dto.MPayDto;
import com.project.ohgym.dto.MemberDto;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Service
@Slf4j
public class dGymGoodsService {

    @Autowired
    private GymGoodsDao gGDao;

    @Autowired
    private MemberDao mDao;

    private ModelAndView mv;

    //헬스장 상품 상세보기
    public ModelAndView getGym(Integer gymnum, HttpSession session){
        log.info("getGym()");
        mv = new ModelAndView();

        MemberDto member = (MemberDto) session.getAttribute("mb");
        //session.setAttribute("mb", member);

        //헬스장 정보 가져오기
        GymDto gym = gGDao.selectGym(gymnum);

        //헬스 상품 정보 가져오기
        List<GymGoodsDto> gGList = gGDao.selectGymGoods(gymnum);
        //GymGoodsDto gymgoods = gGDao.selectGymGoods(gymnum);

        //가져온 데이터 mv에 담기
        mv.addObject("mb", member); //회원 정보
        mv.addObject("gym", gym); //헬스장 정보
        mv.addObject("gGList", gGList); //헬스장 상품 정보


        //mv에 view 지정하기
        mv.setViewName("gymPay");

        return mv;
    }

    public List<MPayDto> dPayment(String mid, Integer gymnum, HttpSession session) {
        log.info("dPayment()");
        List<MemberDto> mList = null;

        //결제한 회원의 정보 업데이트

        return null;
    }
}
