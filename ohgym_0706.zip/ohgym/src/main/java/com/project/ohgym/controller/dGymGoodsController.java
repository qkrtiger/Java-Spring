package com.project.ohgym.controller;

import com.project.ohgym.dto.MPayDto;
import com.project.ohgym.dto.MemberDto;
import com.project.ohgym.service.dGymGoodsService;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.lang.reflect.Member;
import java.util.List;

@Controller
@Slf4j
public class dGymGoodsController {

    @Autowired
    private dGymGoodsService dGGServ;

    private ModelAndView mv;

    @GetMapping("/")
    public String home(){
        log.info("home()");
        return "testlist";
    }

    @GetMapping("gymPay")
    public ModelAndView gymPayContents(Integer gymnum, HttpSession session){
        log.info("gymPay()");

        mv = dGGServ.getGym(gymnum, session);

        return mv;
    }

    @PostMapping("payment")
    @ResponseBody
    public List<MPayDto> payment(String membernum, Integer mpaynum, HttpSession session){
        log.info("payment()");
        List<MPayDto> mPayList = dGGServ.dPayment(membernum, mpaynum, session);

        return mPayList;
    }

}
