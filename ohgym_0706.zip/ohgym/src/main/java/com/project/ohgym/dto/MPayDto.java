package com.project.ohgym.dto;

public class MPayDto {
    private int mpaynum;
    private int membernum;
    private String mpaymethod;
    private String mpayproduct;
    private String mpaydate;
    private String mpaygym;
    private String mpayperiod;
    private String mpaytime;
    private String trainername;
    private int ggoodsnum;
    private int tgoodsint;
}
