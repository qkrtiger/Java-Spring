package com.project.ohgym.dao;

import com.project.ohgym.dto.MemberDto;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MemberDao {

    //회원의 비밀번호 검색 메소드
    String selectPass(String mid);
    //회원 정보를 가져오는 메소드(from member 테이블)
    MemberDto selectMember(String mid);

}
