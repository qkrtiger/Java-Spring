package com.project.ohgym.controller;

import com.project.ohgym.dto.MemberDto;
import com.project.ohgym.service.mLoginService;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@Slf4j
public class mLoginController {
    @Autowired
    private mLoginService mServ;

    @GetMapping("loginForm")
    public String loginForm(){
        log.info("loginForm()");
        return "loginForm";
    }

    @PostMapping("loginProc")
    public String loginProc(MemberDto member,
                            HttpSession session,
                            RedirectAttributes rttr){
        log.info("loginProc()");
        String view = mServ.loginProc(member, session, rttr);
        return view;
    }

}
